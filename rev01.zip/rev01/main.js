/* ----------------------------------------------------------------
                      AutosarEcucParser
---------------------------------------------------------------- */
const XML_NS_URL      = "http://autosar.org/schema/r4.0";
const MAX_TREE_LEVEL  = 10;

class DomWrapper {

  constructor(fileDom) {
    this.fileDom = fileDom;
  }

  resolver() {
    return XML_NS_URL;
  }

  getTagText(node, tag) {
    let retval;
    const xPathResult = this.evaluate(tag, node, XPathResult.ANY_TYPE, null);
    const next = xPathResult.iterateNext();

     retval = (next == null) ? '(None)': next.textContent;

    return retval;
  }

  evaluate(expression, contextNode, type, xPathResult) {
    return this.fileDom.evaluate(expression, contextNode, this.resolver, type, xPathResult);
  }
};

class TreeContext {

  constructor(fileDomWrapper) {
    this.fileDomWrapper = fileDomWrapper;
    this.treeContext    = new Array();
  }

  push(node) {
    this.treeContext.push(node);
  }

  pop() {
    this.treeContext.pop();
  }

  getTreeContextAsNames() {
    let treeContextAsNames = new Array();

    this.treeContext.forEach( (node) => {
      treeContextAsNames.push( this.fileDomWrapper.getTagText(node, 'ns:SHORT-NAME') );
    });

    if(MAX_TREE_LEVEL > treeContextAsNames.length) {
      const repeatNum = MAX_TREE_LEVEL - treeContextAsNames.length;
      for(var i = 0; i < repeatNum; ++i) {
        treeContextAsNames.push("");
      }
    }

    return treeContextAsNames;
  }

  getModuleName() {
    const moduleName = this.fileDomWrapper.getTagText(this.treeContext[0], 'ns:SHORT-NAME');
    return moduleName;
  }
};

class AutosarEcucParserBase {

  constructor(fileDom) {
    this.fileDomWrapper = new DomWrapper(fileDom);
    this.treeContext    = new TreeContext(this.fileDomWrapper);
  }

  notFoundHandler() {
  }

  #processCommon(searchExp, searchContext, funcFound) {
    let xPathResult = this.fileDomWrapper.evaluate(searchExp, searchContext, XPathResult.ANY_TYPE, null);
    let next = xPathResult.iterateNext();

    if( next == null ) {
      this.notFoundHandler();
    } else {
      do {
        funcFound(next);
        next = xPathResult.iterateNext();
      } while( next != null);
    }
  }

  #processFile() {
    this.#processCommon('//ns:ECUC-MODULE-DEF', this.fileDomWrapper.fileDom, (module) => {
      this.treeContext.push(module);

      this.found_module(module);
      this.#processModule(module);

      this.treeContext.pop();
    });
  }

  #processModule(module) {
    this.#processCommon('ns:CONTAINERS/ns:ECUC-PARAM-CONF-CONTAINER-DEF', module, (container) => {
      this.treeContext.push(container);

      this.found_container(container);
      this.#processContainer(container);

      this.treeContext.pop();
    });
  }

  #processContainer(container) {
    this.#processCommon('ns:PARAMETERS/*', container, (parameter) => {
      this.found_parameter(parameter);
    });

    const subContainerCallback = ((subContainer) => {
      this.treeContext.push(subContainer);

      this.found_subContainer(subContainer);
      this.#processContainer(subContainer);

      this.treeContext.pop();
    });

    this.#processCommon('ns:SUB-CONTAINERS/ns:ECUC-PARAM-CONF-CONTAINER-DEF', container, subContainerCallback);
    this.#processCommon('ns:SUB-CONTAINERS/ns:ECUC-CHOICE-CONTAINER-DEF',     container, subContainerCallback);
    this.#processCommon('ns:CHOICES/ns:ECUC-PARAM-CONF-CONTAINER-DEF',        container, subContainerCallback);
  }

  parse() {
    this.#processFile()
  }

  // Protected functions
  found_module(module)                          {}
  found_container(container)                    {}
  found_subContainer(subContainer)              {}
  found_parameter(parameter)                    {}
};

class AutosarEcucParser extends AutosarEcucParserBase {

  constructor(fileDom, outputObject) {
    super(fileDom);
    this.outputObject = outputObject;
  }

  found_module(module) {
    const shortName = this.fileDomWrapper.getTagText(module, 'ns:SHORT-NAME');
    const desc      = this.fileDomWrapper.getTagText(module, 'ns:DESC/ns:L-2');

    this.outputObject.modules.push([shortName, desc]);
    this.outputObject.parameters[shortName] = new Array();
  }

  found_container(container) {
    const shortName = this.fileDomWrapper.getTagText(container, 'ns:SHORT-NAME');
    const desc      = this.fileDomWrapper.getTagText(container, 'ns:DESC/ns:L-2');

    this.outputObject.containers.push([shortName, desc]);
  }

  found_subContainer(container) {
    this.found_container(container);
  }

  found_parameter(parameter) {
    const tagName     = parameter.localName;
    const shortName   = this.fileDomWrapper.getTagText(parameter, 'ns:SHORT-NAME');
    const desc        = this.fileDomWrapper.getTagText(parameter, 'ns:DESC/ns:L-2');
    const treeContent = this.treeContext.getTreeContextAsNames();
    const module      = this.treeContext.getModuleName();

    this.outputObject.parameters[module].push(treeContent.concat([shortName, tagName, desc]));
  }
};

/* ----------------------------------------------------------------
                      Main
---------------------------------------------------------------- */
class OutputObject {

  constructor() {
    this.modules     = new Array();
    this.containers  = new Array();
    this.parameters  = new Object();
  };
}

document.body.addEventListener('dragover', (e) => {
  e.stopPropagation();
  e.preventDefault();
});

class View_Status {

  constructor() {
    this.tag = document.getElementById('status');
  }

  clear() {
    this.tag.innerHTML = '<ul id="status_lines"></ul>';
  }

  update(level, str) {
    let status  = document.getElementById('status_lines');
    let line    = document.createElement('li');

    const getDateTimeStr = ( () => {
      const dateObj = new Date();
      const options = {year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric'};
      const dateStr = new Intl.DateTimeFormat('en-US', options).format(dateObj);

      return dateStr;
    });

    line.innerHTML    = '<span class="datetime">' + getDateTimeStr() + '</span>' + '[' + level + '] ' + str;
    line.setAttribute('level', level);
    status.appendChild(line);
  }
};

function analysis_checkPreCondition(files) {
  let retval = true;
  const SUPPORT_EXTENSIONS = ["arxml", "bswmd"];

  view_status.update('INFO', '[Step 1/4] Checking precoditions... ');

  const getExtension = ((filename) => {
    let parts = filename.split('.');
    return parts[parts.length - 1];
  });

  for (var i = 0; i < files.length; ++i) {
    let ext = getExtension(files[i].name);

    if( !SUPPORT_EXTENSIONS.includes(ext) ) {
      view_status.update('ERROR', 'Unsupported file extension detected: ' + files[i].name);
      retval = false;
      break;
    }
  }

  return retval;
}

async function asyncOpenFiles(files) {
  let fileDoms      = new Array();

  view_status.update('INFO', '[Step 2/4] Opening files... ');

  for (var i = 0; i < files.length; ++i) {
    view_status.update('INFO', 'Opening file: ' + files[i].name);

    const xml = new FileReader();
    const fileText  = await files[i].text();
    const parser = new DOMParser();
    const fileDom = parser.parseFromString(fileText, 'application/xml');
    fileDoms.push(fileDom);
  }

  return fileDoms;
}

function analyzeFileDoms(files, fileDoms) {
  view_status.update('INFO', '[Step 3/4] Analyzing Xmls... ');

  let outputObject  = new OutputObject();

  for (var i = 0; i < files.length; ++i) {
    view_status.update('INFO', 'Analyzing Xml: ' + files[i].name);
    let autosarEcucParser = new AutosarEcucParser(fileDoms[i], outputObject);
    autosarEcucParser.parse();
  }

  view_status.update('INFO', '[Step 4/4] Generating Excel files... ');

  // Modules
  let wb = XLSX.utils.book_new();
  let ws_modules = XLSX.utils.aoa_to_sheet(outputObject.modules);
  XLSX.utils.book_append_sheet(wb, ws_modules, "modules");

  // Parameters
  for (var module in outputObject.parameters) {
    let ws = XLSX.utils.aoa_to_sheet(outputObject.parameters[module]);
    XLSX.utils.book_append_sheet(wb, ws, module);
  }

  XLSX.writeFile(wb, "Configuration_Modules.xlsx");
}

document.body.addEventListener('drop', async(e) => {
  e.stopPropagation();
  e.preventDefault();
  let files = e.dataTransfer.files

  view_status.clear();

  let isPreconditionOk = analysis_checkPreCondition(files);

  if( isPreconditionOk ) {
    asyncOpenFiles(files).then( (fileDoms) => {
      analyzeFileDoms(files, fileDoms);

      view_status.update('INFO', 'Completed!');
    });
  }
});

let view_status = new View_Status();